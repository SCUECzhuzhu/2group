<?php
/**
 * Created by PhpStorm.
 * User: ly
 * Date: 2016/7/25
 * Time: 10:29
 *///使用会话内存储的变量值之前必须先开启会话
session_start();
//使用一个会话变量检查登录状态
if(isset($_SESSION['username'])){
    //echo 'You are Logged as '.$_SESSION['username'].'<br/>';
    //点击“Log Out”,则转到logOut页面进行注销
    $name=$_SESSION['username'];
    echo 'this is your name'.$name."<br/><br/><br/><br/>";
    $mysql	=	new SaeMysql();

    $sql	=	"SELECT * FROM `record` WHERE `id`='1'";

    $row	=	$mysql->getLine($sql);

    $sql	=	"SELECT * FROM `record` where name='$name' limit 5";

    $result	=	$mysql->getData($sql);

    foreach ($result as $row)
    {
        foreach ($row as $key=>$value)
        {
            echo $key."=>".$value."<br/>";
        }
        echo "-----------}-----------<br/>";

        $mysql->closeDb();  }

    echo '<a href="logOut.php"> Log Out('.$_SESSION['username'].')</a>';
}
?>
