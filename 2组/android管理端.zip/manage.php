<html>
    <head lang="en">
    <meta charset="UTF-8">
    <title>管理界面</title>
</head>
<body>
<?php
/**
 * Created by PhpStorm.
 * User: ly
 * Date: 2016/7/29
 * Time: 9:26
 */
$mysql	=	new SaeMysql();
$sql="SELECT name, sum( frequency )
FROM (
SELECT name, frequency
FROM record
WHERE HOUR
BETWEEN 9
AND 12
AND date_format( now( ) , '%Y-%m-%d' ) = time
) AS a
GROUP BY name limit 1";
$mysql->runSql($sql);
$row	=	$mysql->getLine($sql);

$sql	=	"SELECT name, sum( frequency )
FROM (
SELECT name, frequency
FROM record
WHERE HOUR
BETWEEN 9
AND 12
AND date_format( now( ) , '%Y-%m-%d' ) = time
) AS a
GROUP BY name";

$result	=	$mysql->getData($sql);
$i=1;
foreach ($result as $row) {      
    
    echo "<p id='$i' >";
    foreach ($row as $key => $value) {
       
        echo $key . ":" . $value . "<br/>";
        $sum=$value;
        
        
    }
       
    
    if($sum<=100){
           echo "<script>document.getElementById($i).style.color='red'</script>";
       } 
    
    echo "-----------------------<br/>";
    echo <<<_END
    <button onclick="demo$i()">已处理</button>
    <script>
        function demo$i(){document.getElementById($i).style.color='black'}
    </script>
_END;
    $i=$i+1;
    echo "</p>";  
}
?>
</body>
    </html>
