<?php
$mail = new SaeMail();
$mail->setAttach( array( 'my_photo' => '照片的二进制数据' ) );
$ret = $mail->quickSend( '1009111876@qq.com' , '啊啊' , '啊' , '419013157@qq.com' , 'dream0908' ); 
//发送失败时输出错误码和错误信息
if ($ret === false)	
    var_dump($mail->errno(), $mail->errmsg()); 
$mail->clean(); 
// 重用此对象
$ret = $mail->quickSend( '1009111876@qq.com' , '啊啊' , '啊' , 'smtpaccount@unknown.com' , 'dream0908' , 'smtp.qq.com' , 25 );
// 指定smtp和端口 
//发送失败时输出错误码和错误信息
if ($ret === false)	
    var_dump($mail->errno(),$mail->errmsg());
?>
