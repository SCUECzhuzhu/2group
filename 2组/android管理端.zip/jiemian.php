<?php
session_start();
require_once("database.php");
$error_msg = "";
$mysql=new SaeMysql();
//如果用户未登录，即未设置$_SESSION['user_id']时，执行以下代码
if(!isset($_SESSION['user_id'])) {
    if (isset($_POST['submit'])) {//用户提交登录表单时执行如下代码
        //$db = new DB();
        $name = $_POST['name'];
        $name = iconv("utf-8", "gbk", $name);
        $passwd = $_POST['passwd'];
        $passwd = iconv("utf-8", "gbk", $passwd);
		$mysql	=	new SaeMysql();
        if (!empty($name) && !empty($passwd)) {
            //MySql中的SHA()函数用于对字符串进行单向加密
            $query = "SELECT user_id, name FROM userdatabase WHERE name = '$name' AND password = '$passwd'";
            //用用户名和密码进行查询
            $result=$mysql->getLine($query);
            //若查到的记录正好为一条，则设置SESSION，同时进行页面重定向
            if ($result==null) {
                $error_msg = 'sorry  enter is wrong';
            } 
            else {                	
                foreach ($result as $key=>$value)
							{	
                    			$row[]="$value";                    
							}               	
                $_SESSION['user_id'] = $row[0];
                $_SESSION['username'] = $row[1];                
            }
        } else {
            $error_msg = 'Sorry, you must enter a valid username and password to log in.';
        }
    }
}else{
    echo <<<_END
	<script>url="loged.php";window.location.href=url;</script>
_END;
}
?>
<html>
<head>
    <title>login</title>
    <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
<h3>login_jiemian</h3>
<!--通过$_SESSION['user_id']进行判断，如果用户未登录，则显示登录表单，让用户输入用户名和密码-->
<?php
if(!isset($_SESSION['user_id'])){
    echo '<p class="error">'.$error_msg.'</p>';
    ?>
    <!-- $_SERVER['PHP_SELF']代表用户提交表单时，调用自身php文件 -->
    <form method = "post" action="<?php echo $_SERVER['PHP_SELF'];?>">
        <fieldset>
            <legend>Log In</legend>

            <label for="name">Username:</label>
            <!-- 如果用户已输过用户名，则回显用户名 -->
            <input type="text" id="name" name="name"
                   value="<?php if(!empty($user_username)) echo $user_username; ?>" />

            <br/>

            <label for="passwd">Password:</label>
            <input type="passwd" id="password" name="passwd"/>

        </fieldset>
        <input type="submit" value="submit" name="submit"/>
    </form>
<?php
}
?>
</body>
</html>
