<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>后台管理</title></head>
<body>

<?php
// Page分页函数
$page = $_GET["page"];
function Page($rows,$page_size){
    global $page,$select_from,$select_limit,$pagenav;
    $page_count = ceil($rows/$page_size);
    if($page <= 1 || $page == '') $page = 1;
    if($page >= $page_count) $page = $page_count;
    $select_limit = $page_size;
    $select_from = ($page - 1) * $page_size.',';
    $pre_page = ($page == 1)? 1 : $page - 1;
    $next_page= ($page == $page_count)? $page_count : $page + 1 ;
    $pagenav .= "第 $page/$page_count 页 共 $rows 条记录 ";
    $pagenav .= "<a href='?page=1'>首页</a> ";
    $pagenav .= "<a href='?page=$pre_page'>前一页</a> ";
    $pagenav .= "<a href='?page=$next_page'>后一页</a> ";
    $pagenav .= "<a href='?page=$page_count'>末页</a>";
    $pagenav.="　跳到<select name='topage' size='1' onchange='window.location=\"?page=\"+this.value'>\n";
    for($i=1;$i<=$page_count;$i++){
        if($i==$page) $pagenav.="<option value='$i' selected>$i</option>\n";
        else $pagenav.="<option value='$i'>$i</option>\n";
    }
} // Page分页函数
// 使用示例
if (!$conn= mysql_connect(SAE_MYSQL_HOST_M . ':' . SAE_MYSQL_PORT, SAE_MYSQL_USER, SAE_MYSQL_PASS)) die('数据库选择失败！');
if (!mysql_select_db(SAE_MYSQL_DB, $conn)) die('数据库选择失败！');
mysql_query('set names GBK');
// 用Page函数计算出 $select_from 从哪条记录开始检索、$pagenav 输出分页导航
$rows = mysql_num_rows(mysql_query("SELECT  name,frequency,time
FROM record
WHERE time
BETWEEN date_sub( now( ) , INTERVAL 1
DAY )
AND now( )
ORDER BY name DESC"));

Page($rows,24);
$sql = "SELECT  name,frequency,time
FROM record
WHERE time
BETWEEN date_sub( now( ) , INTERVAL 1
DAY )
AND now( )
ORDER BY name DESC limit $select_from $select_limit";
$rst = mysql_query($sql);
while ($row = mysql_fetch_array($rst)){
    echo "$row[name] - $row[frequency] - $row[time]<hr />";
}
echo $pagenav;
?> 
    </body>

</html>