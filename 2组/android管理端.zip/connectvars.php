<?php
/**
 * Created by PhpStorm.
 * User: ly
 * Date: 2016/7/25
 * Time: 10:14
 */
define('DB_HOST', 'localhost');
//用户名
define('DB_USER', 'root');
//口令
define('DB_PASSWORD', 'dream0908');
//数据库名
define('DB_NAME','liyue') ;
?>