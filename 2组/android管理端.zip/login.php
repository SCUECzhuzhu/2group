
<?php
require_once("database.php");
$db = new DB();
$name = $_POST['name'];
$name = iconv("utf-8","gbk",$name);
$password = $_POST['passwd'];
$password = iconv("utf-8","gbk",$password);
echo 'this name is: '.$name;
echo 'this passwod is: '.$password;
//查看用户名和密码是否正确
$sql = "select name from `userdatabase` where name='%s' and password='%s' limit 1";
$sql = sprintf($sql, $name, $password);
$result = $db->select($sql);
if (!count($result)){
    $ret['success'] = "false";
    $ret['result'] = "ths connection is faild";
    $json = json_encode($ret);
    
    echo $json;
    exit;
}


    
//密码或用户名正确
$ret['success'] = "true";
$ret['result'] = "this connection is success";
$json = json_encode($ret);
echo $json;
exit;
?>
